-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(990080)
addappid(990081,0,"99edd7f3221635d93481770b28ebac240488e1f42cf16f01e5a4e744b0944da6")
addappid(990082,0,"ac55581fbdef1f6687f91654d435e2d4c395d2fa56eb5aba4fa52d708118157e")
addappid(990083,0,"2326f907ccd6ebfc8235495fbb2abd7b12d814a3228cd3b0bf480f7c602c87f5")
addappid(990084,0,"f043f2ca0cfbbaf5fcb6e30d4beb1a20ba5ef293db11dc4e5521bdfa8a7fdfe0")
addappid(990085,0,"b7d07ff314786df30f9d32266a2e88cd026fabaffbd2567dbc1637cd319ef996")
addappid(990086,0,"d9814846faaa5f83e45151bec5190062e320c6b9a6842e7722ed51293a29a667")
addappid(990087,0,"42c46e0e1520cefc9f4120f00fca640bc83f48b322e7b19ad9530538d9cbee75")
addappid(990088,0,"81c364d84279c2fafb7960d0aabd75e7e371ad27f275484d99ef5734e4c00d95")
addappid(990089,0,"21886ab063a78ccf9b676f311597b895c73a1410cd9f7e0e3e7b4e99b82f1e6b")
addappid(1880830)
addappid(1880832)
addappid(1880833)
addappid(1880837)
