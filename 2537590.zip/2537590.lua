-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2537590)
addappid(2537591,0,"a149759cc259406fd0f2255297e089d9deb63fb59c263b7f2d1b7fcd7aded1a4")
addappid(3227340)
addappid(3245690)
addappid(3245700)
addappid(3245710)
addappid(3341960)
