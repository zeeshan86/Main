LUA Collection — Credits & Info
===============================

All files in this package were prepared by K3rnelPan1c5750.

Credits
-------
- Discord: https://discord.gg/k3rnalyze
- Website: https://kernelos.org/games
- Twitter: https://x.com/KernelPan1c5750

Notes
-----
- LUA files include a credit header at the top (as Lua comments).
- Each ZIP contains a single LUA plus this README for credits.

Prepared for distribution.
