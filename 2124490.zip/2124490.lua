-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2124490)
addappid(2124491,0,"1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955")
addappid(2951540)
addappid(3097490)
addappid(3097500)
