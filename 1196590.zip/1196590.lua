-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1196590)
addappid(1196591,0,"7ccf761ec4f6be4f36416cd1304044deb8b419204f823cae95c9d9f64f94297c")
addappid(1196593,0,"95a6023be95ec2186ae5340ee6b7e84f093106e5944e1c8ca09b884622dc41e6")
addappid(1456360,0,"ba65fa909516f46db9fd95fb6a0e266c4d244b386d260346272290642726b63e")
addappid(1456361,0,"c847c83484f69cc3195464a7153560fafdd9ec985afb7bf13e2e48ea552dee6d")
addappid(1456362,0,"46bff99e18ca51b8748333d1dafa1f759b59ca126d648bba42ec8ad386d83827")
addappid(1456363,0,"39be524780f16cc175cb4e9813d4d4bb50152d4f72be6a4ea0cb23cf7f4669d3")
addappid(1731080,0,"caa8356d4e747e982b77b28cfcb1df9095bea681dfae768c0a727a3cd96a9279")
addappid(1731081,0,"69638321e164cb5fd216b2ab217bffa7073fce678124665c60934e972bcf0c2e")
