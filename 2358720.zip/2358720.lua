-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(229006)
addappid(2358720)
addappid(2358721,0,"78d5a284965b2206de191dc4ca99d43c9caf5b5e78b47cf0c366fbbb884190d8")
addappid(2672610)
