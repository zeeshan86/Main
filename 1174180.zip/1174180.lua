-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(228987)
addappid(228990)
addappid(1174180)
addappid(1174181,0,"6fbf0f4b33fd5111d0832f0fb63a4d185c5321901ef95776c73e6e10b203bc25")
addappid(1174182,0,"0824e4e00b9d464a1352b0eaa60416ee3bfe0f3b416459991dc6fca87e84366f")
addappid(1174183,0,"cd51ee7e8adde797736bc283f9d434fae0aac28753e3f38a29a78aac298c0ccf")
addappid(1174184,0,"506c8f971b77f5c39f8baa54fac090e79bf32e19d92eca2a34cba9569bbe5d8a")
addappid(1174185,0,"6fe9c5b4e41f1f91b6a775dd562515e9652570cc607caedef2bc4a9d522fea4d")
addappid(1174186,0,"0ef7331ad866994474a72131eeb1a5667dc8c9f7be87b4e1d805f288e1d49432")
addappid(1190050)
addappid(1190051)
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
